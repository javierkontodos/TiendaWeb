package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Modelo.Producto;
import Singleton.DBConnection;

public class DaoProducto {
	/*
	 * PROPIEDADES Y M�TODOS SINGLETON
	 */

	private Connection con = null;

	private static DaoProducto instance = null;

	private DaoProducto() throws SQLException {
		con = DBConnection.getConnection();
	}

	public static DaoProducto getInstance() throws SQLException {
		if (instance == null)
			instance = new DaoProducto();

		return instance;
	}

	/*
	 * METODOS PROPIOS DE LA CLASE DAO
	 */

	public void insert(Producto p) throws SQLException {

		PreparedStatement ps = con.prepareStatement(
				"INSERT INTO producto(nombre, descripcion, precio, foto) VALUES (?, ?, ?, ?)");
		ps.setString(1, p.getNombre());
		ps.setString(2, p.getDescripcion());
		ps.setDouble(3, p.getPrecio());
		ps.setString(4, p.getFoto());
		
		ps.executeUpdate();

		ps.close();

	}

	public List<Producto> findAll() throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM producto");
		ResultSet rs = ps.executeQuery();

		List<Producto> result = null;

		while (rs.next()) {
			if (result == null)
				result = new ArrayList<>();

			result.add(new Producto(rs.getInt("id"), rs.getString("nombre"), rs.getString("descripcion"), rs.getDouble("precio"), rs.getString("foto")));
		}

		rs.close();
		ps.close();

		return result;
	}

	public Producto findByPk(int id) throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM producto WHERE id = ?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();

		Producto result = null;

		if (rs.next()) {
			result = new Producto(rs.getInt("id"), rs.getString("nombre"), rs.getString("descripcion"), rs.getDouble("precio"), rs.getString("foto"));
		}

		rs.close();
		ps.close();

		return result;

	}

	public void delete(Producto p) throws SQLException {
		delete(p.getId());
	}
	
	public void delete(int id) throws SQLException {
		
		if (id <= 0)
			return;
		
		PreparedStatement ps = con.prepareStatement("DELETE FROM producto WHERE id = ?");
		ps.setInt(1, id);

		ps.executeUpdate();

		ps.close();
	}

	public void update(Producto p) throws SQLException {

		if (p.getId() == 0)
			return;

		PreparedStatement ps = con.prepareStatement(
				"UPDATE producto SET nombre = ?, descripcion = ?, precio = ?, foto = ? WHERE id = ?");

		ps.setString(1, p.getNombre());
		ps.setString(2, p.getDescripcion());
		ps.setDouble(3, p.getPrecio());
		ps.setString(4, p.getFoto());
		ps.setInt(5, p.getId());
		
		ps.executeUpdate();
		
		ps.close();

	}
}
