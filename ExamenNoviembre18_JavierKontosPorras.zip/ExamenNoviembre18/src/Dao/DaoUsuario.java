package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Modelo.Usuario;
import Singleton.DBConnection;

public class DaoUsuario {
	/*
	 * PROPIEDADES Y METODOS SINGLETON
	 */

	private Connection con = null;

	private static DaoUsuario instance = null;

	private DaoUsuario() throws SQLException {
		con = DBConnection.getConnection();
	}

	public static DaoUsuario getInstance() throws SQLException {
		if (instance == null)
			instance = new DaoUsuario();

		return instance;
	}

	/*
	 * METODOS PROPIOS DE LA CLASE DAO
	 */

	public void insert(Usuario u) throws SQLException {

		PreparedStatement ps = con.prepareStatement(
				"INSERT INTO usuario(nombre, pass, mail, tel, foto) VALUES (?, ?, ?, ?, ?)");
		ps.setString(1, u.getNombre());
		ps.setString(2, u.getPass());
		ps.setString(3, u.getMail());
		ps.setString(4, u.getTel());
		ps.setString(5, u.getFoto());
		
		ps.executeUpdate();

		ps.close();

	}

	public List<Usuario> findAll() throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM usuario");
		ResultSet rs = ps.executeQuery();

		List<Usuario> result = null;

		while (rs.next()) {
			if (result == null)
				result = new ArrayList<>();

			result.add(new Usuario(rs.getInt("id"), rs.getString("nombre"), rs.getString("pass"), rs.getString("mail"), rs.getString("tel"), rs.getString("foto")));
		}

		rs.close();
		ps.close();

		return result;
	}

	public Usuario findByPk(int id) throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM usuario WHERE id = ?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();

		Usuario result = null;

		if (rs.next()) {
			result = new Usuario(rs.getInt("id"), rs.getString("nombre"), rs.getString("pass"), rs.getString("mail"), rs.getString("tel"), rs.getString("foto"));
		}

		rs.close();
		ps.close();

		return result;

	}
	
	public Usuario findByMail(String mail) throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM usuario WHERE mail = ?");
		ps.setString(1, mail);
		ResultSet rs = ps.executeQuery();

		Usuario result = null;

		if (rs.next()) {
			result = new Usuario(rs.getInt("id"), rs.getString("nombre"), rs.getString("pass"), rs.getString("mail"), rs.getString("tel"), rs.getString("foto"));
		}

		rs.close();
		ps.close();

		return result;

	}
	
	public int findByMailAndPass(String mail, String pass) throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT id FROM usuario WHERE mail = ? AND pass = ?");
		ps.setString(1, mail);
		ps.setString(2, pass);
		ResultSet rs = ps.executeQuery();

		int result = 0;

		if (rs.next()) {
			result = rs.getInt("id");
		}
		
		rs.close();
		ps.close();
		
		return result;
	}

	public void delete(Usuario u) throws SQLException {
		delete(u.getId());
	}
	
	public void delete(int id) throws SQLException {
		
		if (id <= 0)
			return;
		
		PreparedStatement ps = con.prepareStatement("DELETE FROM usuario WHERE id = ?");
		ps.setInt(1, id);

		ps.executeUpdate();

		ps.close();
	}

	public void update(Usuario u) throws SQLException {

		if (u.getId() == 0)
			return;

		PreparedStatement ps = con.prepareStatement(
				"UPDATE usuario SET nombre = ?, pass = ?, mail = ?, tel = ?, foto = ? WHERE id = ?");

		ps.setString(1, u.getNombre());
		ps.setString(2, u.getPass());
		ps.setString(3, u.getMail());
		ps.setString(4, u.getTel());
		ps.setString(5, u.getFoto());
		ps.setInt(6, u.getId());
		
		ps.executeUpdate();
		
		ps.close();

	}
	
}
