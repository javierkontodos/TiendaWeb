package Controlador;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Modelo.Usuario;

/**
 * Servlet implementation class Glogin
 */
@WebServlet("/Gusuarios")
public class Gusuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Gusuarios() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void principal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		int menu = Integer.parseInt(request.getParameter("menu"));
		
		switch (menu) {
		case 1:
			iniciarSesion(request, response);
			break;
		case 2:
			cerrarSesion(request, response);
			break;
		case 3:
			crearUsuario(request, response);
			break;
		default:
			break;
		}
	}
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			this.principal(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void crearUsuario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		if(session.getAttribute("nombre") != null) {
			session.removeAttribute("usuario");
		}
		response.sendRedirect("index.jsp");
	}
	
	protected void iniciarSesion(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		HttpSession sesion = request.getSession();
		
		Usuario user = new Usuario();
		user.setMail(request.getParameter("mail"));
		user.setPass(request.getParameter("pass"));
		
		if(user.login()) {
			sesion.setAttribute("user", request.getParameter("mail"));
			if(user.getMail().equals("antonio@flotaestelar.com")) {
				response.sendRedirect("gestion/index.jsp");
			}else {
				response.sendRedirect("index.jsp");
			}
		}else {
			response.sendRedirect("index.jsp");
		}
	}
	
	protected void cerrarSesion(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		if(session.getAttribute("user") != null) {
			session.removeAttribute("user");
		}
		response.sendRedirect("index.jsp");
	}

}
