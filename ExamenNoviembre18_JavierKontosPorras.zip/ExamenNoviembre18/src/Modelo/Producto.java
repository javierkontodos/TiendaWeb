package Modelo;

import java.sql.SQLException;
import java.util.List;

import Dao.DaoProducto;

public class Producto {
	private int id;
	private String nombre;
	private String descripcion;
	private double precio;
	private String foto;
	/**
	 * Contructor vacio
	 */
	public Producto() {
		
	}
	/**
	 * @param id
	 * @param nombre
	 * @param descripcion
	 * @param precio
	 * @param foto
	 */
	public Producto(int id, String nombre, String descripcion, double precio, String foto) {
		this.id = id;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.precio = precio;
		this.foto = foto;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the precio
	 */
	public double getPrecio() {
		return precio;
	}
	/**
	 * @param precio the precio to set
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	/**
	 * @return the foto
	 */
	public String getFoto() {
		return foto;
	}
	/**
	 * @param foto the foto to set
	 */
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	public String listadoProductos() throws SQLException {
		String txt = new String();
		
		DaoProducto dao = DaoProducto.getInstance();		
		
		List<Producto> lista = null;
		try {
			lista = dao.findAll();
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		if (lista != null) {
			for (Producto pro : lista) {
				txt += "<div class='producto'><div class='productoFoto'><img src='"+pro.getFoto()+"'></div><div class='productoDatos'><h1>"+pro.getNombre()+"</h1><p>"+pro.getDescripcion()+"</p><h2>"+pro.getPrecio()+" Euros</h2><button>Compar</button></div></div>";
			}
		}
		
		return txt;
	}
}
