package Modelo;

import java.sql.SQLException;

import Dao.DaoUsuario;

public class Usuario {
	private int id;
	private String nombre;
	private String pass;
	private String mail;
	private String tel;
	private String foto;
	
	public Usuario() {
		
	}

	/**
	 * @param id
	 * @param nombre
	 * @param pass
	 * @param email
	 * @param tel
	 * @param foto
	 */
	public Usuario(int id, String nombre, String pass, String mail, String tel, String foto) {
		this.id = id;
		this.nombre = nombre;
		this.pass = pass;
		this.mail = mail;
		this.tel = tel;
		this.foto = foto;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}
	
	/**
	 * @param email the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}
	
	/**
	 * @param tel the tel to set
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	/**
	 * @return the foto
	 */
	public String getFoto() {
		return foto;
	}
	
	/**
	 * @param foto the foto to set
	 */
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	public Boolean login() throws SQLException {
		Boolean logear= false;
		DaoUsuario dao = DaoUsuario.getInstance();
		
		if(dao.findByMailAndPass(mail, pass) > 0) {
			logear = true;
		}
		
		return logear;
	}
	
	/*public String gererarPerfil(String mail) throws SQLException {
		String txt = new String();
		
		DaoUsuario dao = DaoUsuario.getInstance();
		Usuario user = dao.findByMail(mail);
		
		txt = "<div id='perfilFoto'><div style=\"background-image: url(\'"+user.getFoto()+"\')\"></div></div>";
		txt += "<div id='perfilDatos'><h1>"+user.getNombre()+"</h1><h3>"+user.getMail()+"</h3><h3>"+user.getTel()+"</h3></div>";
		txt += "<div id='perfilUsuario'><form name='actUser' action='Gusuarios' method='post'>"
				+ "<ul><li><label>Nombre de Usuario</label></li><li><input type='text' name='nombre' value='"+user.getNombre()+"'></li></ul>"
				+ "<ul><li><label>Correo Electronico</label></li><li><input type='text' name='mail' value='"+user.getMail()+"'></li></ul>"
				+ "<ul><li><input type='button' name='guardar' value='GUARDAR' onclick='validar_perfilUser()'></li></ul></form></div>";
		txt += "<div id='perfilPass'><form name='actPass' action='Gusuarios' method='post'>"
				+ "<ul><li><label>Antigua contraseña</label></li><li><input type='password' name='pass'></li></ul>"
				+ "<ul><li><label>Nueva contraseña</label></li><li><input type='password' name='actPass'></li></ul>"
				+ "<ul><li><label>Repetir contraseña</label></li><li><input type='password' name='actPass2'></li></ul>"
				+ "<ul><li><input type='button' name='guardar' value='GUARDAR' onclick='validar_perfilPass()'></li></ul></form></div>";
		return txt;
	}*/
}
