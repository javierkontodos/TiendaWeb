function validar_login() {
    var ok = true;
    var formulario = document.login;
    for (var i=0;i<formulario.elements.length;i++){
        if (formulario.elements[i]!=formulario.acceder) {
            if(!formulario.elements[i].value){
                formulario.elements[i].style.border = '2px solid #FE4343';
                ok = false;
            }else{
                formulario.elements[i].style.border = '2px solid #61D528';
            }
        }
        
    }
    if (ok) {
        formulario.submit();
    }
}
function validar_registro() {
    var ok = true;
    var formulario = document.registro;
    for (var i=0;i<formulario.elements.length;i++){
        if (formulario.elements[i]!=formulario.acceder) {
            if(!formulario.elements[i].value){
                formulario.elements[i].style.border = '2px solid #FE4343';
                ok = false;
            }else{
                formulario.elements[i].style.border = '2px solid #61D528';
            }
        }
        
    }
    if (ok) {
        formulario.submit();
    }
}
function verLogin(){
	document.getElementById('login').style.display = "block";
	document.getElementById('fondoNegro').style.display = "block";
}
function verRegistro(){
	document.getElementById('registro').style.display = "block";
	document.getElementById('fondoNegro').style.display = "block";
}
function cerrarLoginRegistro(){
	document.getElementById('login').style.display = "none";
	document.getElementById('registro').style.display = "none";
	document.getElementById('fondoNegro').style.display = "none";
}